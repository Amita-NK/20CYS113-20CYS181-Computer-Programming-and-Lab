elements = [0] * (5)

for index in range(0, 4 + 1, 1):
    print("Enter element for index=[" + str(index) + "]")
    element = int(input())
    elements[index] = element
print("Array contents")
for index in range(0, 4 + 1, 1):
    print("Array content elements[" + str(index) + "]=" + str(elements[index]))
print("Largest element number between 1-5")
print("5")
