print("Enter the value for the integer a")
a = int(input())
print("Enter the value for integer b")
b = int(input())
c = a + b
print(c)
