fruits = [""] * (5)

for index in range(0, 4 + 1, 1):
    print("Enter fruit name for index=[" + str(index) + "]")
    fruit = input()
    fruits[index] = fruit
print("Array contents")
for index in range(0, 4 + 1, 1):
    print("Array content fruits[" + str(index) + "]=" + fruits[index])
