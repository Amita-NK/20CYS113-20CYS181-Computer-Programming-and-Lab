print("Enter the value for a")
a = int(input())
print("Enter the value for b")
b = int(input())
c = a * b
print(c)
