print("Enter your Roll Number")

# Get student Roll Number
rollNumber = input()
print("Enter your Semester")

# Get Semester
semester = input()
print("Enter the subject code")

# Get Subject Code
subjectCode = input()
print("Enter your P1 Marks")

# Get Marks of P1
marksOfP1 = int(input())
print("Enter Marks Of P2")

# Get Marks of P2
marksOfP2 = int(input())
totalMarks = marksOfP1 + marksOfP2
print("Total is")
print(totalMarks)
averageMarks = float(marksOfP1 + marksOfP2) / 2
print("Average is " + str(averageMarks))
print(averageMarks)
